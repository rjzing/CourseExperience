﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class frmServer
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.txtLog = New System.Windows.Forms.TextBox()
        Me.txtPort = New System.Windows.Forms.TextBox()
        Me.lblPort = New System.Windows.Forms.Label()
        Me.btnStartServer = New System.Windows.Forms.Button()
        Me.btnStopServer = New System.Windows.Forms.Button()
        Me.gbxPlayer = New System.Windows.Forms.GroupBox()
        Me.rbtnO = New System.Windows.Forms.RadioButton()
        Me.rbtnX = New System.Windows.Forms.RadioButton()
        Me.gbxFirst = New System.Windows.Forms.GroupBox()
        Me.rbtnOFirst = New System.Windows.Forms.RadioButton()
        Me.rbtnXFirst = New System.Windows.Forms.RadioButton()
        Me.btnSubmitStart = New System.Windows.Forms.Button()
        Me.pnlSetUp = New System.Windows.Forms.Panel()
        Me.lblWinner = New System.Windows.Forms.Label()
        Me.btnP0 = New System.Windows.Forms.Button()
        Me.btnP1 = New System.Windows.Forms.Button()
        Me.btnP2 = New System.Windows.Forms.Button()
        Me.btnP3 = New System.Windows.Forms.Button()
        Me.btnP4 = New System.Windows.Forms.Button()
        Me.btnP5 = New System.Windows.Forms.Button()
        Me.btnP6 = New System.Windows.Forms.Button()
        Me.btnP7 = New System.Windows.Forms.Button()
        Me.btnP8 = New System.Windows.Forms.Button()
        Me.pnlBoard = New System.Windows.Forms.Panel()
        Me.ShapeContainer2 = New Microsoft.VisualBasic.PowerPacks.ShapeContainer()
        Me.LineShape4 = New Microsoft.VisualBasic.PowerPacks.LineShape()
        Me.LineShape3 = New Microsoft.VisualBasic.PowerPacks.LineShape()
        Me.LineShape2 = New Microsoft.VisualBasic.PowerPacks.LineShape()
        Me.LineShape1 = New Microsoft.VisualBasic.PowerPacks.LineShape()
        Me.gbxPlayer.SuspendLayout()
        Me.gbxFirst.SuspendLayout()
        Me.pnlSetUp.SuspendLayout()
        Me.pnlBoard.SuspendLayout()
        Me.SuspendLayout()
        '
        'txtLog
        '
        Me.txtLog.Location = New System.Drawing.Point(45, 224)
        Me.txtLog.Margin = New System.Windows.Forms.Padding(1, 1, 1, 1)
        Me.txtLog.Multiline = True
        Me.txtLog.Name = "txtLog"
        Me.txtLog.ReadOnly = True
        Me.txtLog.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.txtLog.Size = New System.Drawing.Size(553, 115)
        Me.txtLog.TabIndex = 0
        Me.txtLog.TabStop = False
        '
        'txtPort
        '
        Me.txtPort.Location = New System.Drawing.Point(484, 65)
        Me.txtPort.Margin = New System.Windows.Forms.Padding(1, 1, 1, 1)
        Me.txtPort.Name = "txtPort"
        Me.txtPort.Size = New System.Drawing.Size(77, 20)
        Me.txtPort.TabIndex = 0
        Me.txtPort.TabStop = False
        '
        'lblPort
        '
        Me.lblPort.AutoSize = True
        Me.lblPort.Location = New System.Drawing.Point(449, 66)
        Me.lblPort.Margin = New System.Windows.Forms.Padding(1, 0, 1, 0)
        Me.lblPort.Name = "lblPort"
        Me.lblPort.Size = New System.Drawing.Size(26, 13)
        Me.lblPort.TabIndex = 0
        Me.lblPort.Text = "Port"
        '
        'btnStartServer
        '
        Me.btnStartServer.Location = New System.Drawing.Point(459, 97)
        Me.btnStartServer.Margin = New System.Windows.Forms.Padding(1, 1, 1, 1)
        Me.btnStartServer.Name = "btnStartServer"
        Me.btnStartServer.Size = New System.Drawing.Size(99, 25)
        Me.btnStartServer.TabIndex = 1
        Me.btnStartServer.Text = "Start Connection"
        Me.btnStartServer.UseVisualStyleBackColor = True
        '
        'btnStopServer
        '
        Me.btnStopServer.Location = New System.Drawing.Point(459, 132)
        Me.btnStopServer.Margin = New System.Windows.Forms.Padding(1, 1, 1, 1)
        Me.btnStopServer.Name = "btnStopServer"
        Me.btnStopServer.Size = New System.Drawing.Size(99, 25)
        Me.btnStopServer.TabIndex = 11
        Me.btnStopServer.Text = "End Connection"
        Me.btnStopServer.UseVisualStyleBackColor = True
        '
        'gbxPlayer
        '
        Me.gbxPlayer.Controls.Add(Me.rbtnO)
        Me.gbxPlayer.Controls.Add(Me.rbtnX)
        Me.gbxPlayer.Location = New System.Drawing.Point(23, 10)
        Me.gbxPlayer.Margin = New System.Windows.Forms.Padding(1, 1, 1, 1)
        Me.gbxPlayer.Name = "gbxPlayer"
        Me.gbxPlayer.Padding = New System.Windows.Forms.Padding(1, 1, 1, 1)
        Me.gbxPlayer.Size = New System.Drawing.Size(121, 53)
        Me.gbxPlayer.TabIndex = 11
        Me.gbxPlayer.TabStop = False
        Me.gbxPlayer.Text = "Player"
        '
        'rbtnO
        '
        Me.rbtnO.AutoSize = True
        Me.rbtnO.Location = New System.Drawing.Point(75, 25)
        Me.rbtnO.Margin = New System.Windows.Forms.Padding(1, 1, 1, 1)
        Me.rbtnO.Name = "rbtnO"
        Me.rbtnO.Size = New System.Drawing.Size(33, 17)
        Me.rbtnO.TabIndex = 0
        Me.rbtnO.Text = "O"
        Me.rbtnO.UseVisualStyleBackColor = True
        '
        'rbtnX
        '
        Me.rbtnX.AutoSize = True
        Me.rbtnX.Location = New System.Drawing.Point(14, 25)
        Me.rbtnX.Margin = New System.Windows.Forms.Padding(1, 1, 1, 1)
        Me.rbtnX.Name = "rbtnX"
        Me.rbtnX.Size = New System.Drawing.Size(32, 17)
        Me.rbtnX.TabIndex = 0
        Me.rbtnX.Text = "X"
        Me.rbtnX.UseVisualStyleBackColor = True
        '
        'gbxFirst
        '
        Me.gbxFirst.Controls.Add(Me.rbtnOFirst)
        Me.gbxFirst.Controls.Add(Me.rbtnXFirst)
        Me.gbxFirst.Location = New System.Drawing.Point(23, 82)
        Me.gbxFirst.Margin = New System.Windows.Forms.Padding(1, 1, 1, 1)
        Me.gbxFirst.Name = "gbxFirst"
        Me.gbxFirst.Padding = New System.Windows.Forms.Padding(1, 1, 1, 1)
        Me.gbxFirst.Size = New System.Drawing.Size(121, 53)
        Me.gbxFirst.TabIndex = 12
        Me.gbxFirst.TabStop = False
        Me.gbxFirst.Text = "First Move"
        '
        'rbtnOFirst
        '
        Me.rbtnOFirst.AutoSize = True
        Me.rbtnOFirst.Location = New System.Drawing.Point(75, 23)
        Me.rbtnOFirst.Margin = New System.Windows.Forms.Padding(1, 1, 1, 1)
        Me.rbtnOFirst.Name = "rbtnOFirst"
        Me.rbtnOFirst.Size = New System.Drawing.Size(33, 17)
        Me.rbtnOFirst.TabIndex = 0
        Me.rbtnOFirst.Text = "O"
        Me.rbtnOFirst.UseVisualStyleBackColor = True
        '
        'rbtnXFirst
        '
        Me.rbtnXFirst.AutoSize = True
        Me.rbtnXFirst.Location = New System.Drawing.Point(14, 23)
        Me.rbtnXFirst.Margin = New System.Windows.Forms.Padding(1, 1, 1, 1)
        Me.rbtnXFirst.Name = "rbtnXFirst"
        Me.rbtnXFirst.Size = New System.Drawing.Size(32, 17)
        Me.rbtnXFirst.TabIndex = 0
        Me.rbtnXFirst.Text = "X"
        Me.rbtnXFirst.UseVisualStyleBackColor = True
        '
        'btnSubmitStart
        '
        Me.btnSubmitStart.Location = New System.Drawing.Point(37, 151)
        Me.btnSubmitStart.Margin = New System.Windows.Forms.Padding(1, 1, 1, 1)
        Me.btnSubmitStart.Name = "btnSubmitStart"
        Me.btnSubmitStart.Size = New System.Drawing.Size(89, 25)
        Me.btnSubmitStart.TabIndex = 13
        Me.btnSubmitStart.Text = "Submit"
        Me.btnSubmitStart.UseVisualStyleBackColor = True
        '
        'pnlSetUp
        '
        Me.pnlSetUp.Controls.Add(Me.gbxPlayer)
        Me.pnlSetUp.Controls.Add(Me.btnSubmitStart)
        Me.pnlSetUp.Controls.Add(Me.gbxFirst)
        Me.pnlSetUp.Location = New System.Drawing.Point(256, 13)
        Me.pnlSetUp.Margin = New System.Windows.Forms.Padding(1, 1, 1, 1)
        Me.pnlSetUp.Name = "pnlSetUp"
        Me.pnlSetUp.Size = New System.Drawing.Size(178, 187)
        Me.pnlSetUp.TabIndex = 14
        '
        'lblWinner
        '
        Me.lblWinner.AutoSize = True
        Me.lblWinner.Location = New System.Drawing.Point(468, 182)
        Me.lblWinner.Margin = New System.Windows.Forms.Padding(1, 0, 1, 0)
        Me.lblWinner.Name = "lblWinner"
        Me.lblWinner.Size = New System.Drawing.Size(0, 13)
        Me.lblWinner.TabIndex = 35
        '
        'btnP0
        '
        Me.btnP0.Location = New System.Drawing.Point(16, 18)
        Me.btnP0.Margin = New System.Windows.Forms.Padding(1, 1, 1, 1)
        Me.btnP0.Name = "btnP0"
        Me.btnP0.Size = New System.Drawing.Size(41, 39)
        Me.btnP0.TabIndex = 2
        Me.btnP0.Tag = ""
        Me.btnP0.UseVisualStyleBackColor = True
        '
        'btnP1
        '
        Me.btnP1.Location = New System.Drawing.Point(71, 18)
        Me.btnP1.Margin = New System.Windows.Forms.Padding(1, 1, 1, 1)
        Me.btnP1.Name = "btnP1"
        Me.btnP1.Size = New System.Drawing.Size(41, 39)
        Me.btnP1.TabIndex = 3
        Me.btnP1.Tag = ""
        Me.btnP1.UseVisualStyleBackColor = True
        '
        'btnP2
        '
        Me.btnP2.Location = New System.Drawing.Point(127, 18)
        Me.btnP2.Margin = New System.Windows.Forms.Padding(1, 1, 1, 1)
        Me.btnP2.Name = "btnP2"
        Me.btnP2.Size = New System.Drawing.Size(41, 39)
        Me.btnP2.TabIndex = 4
        Me.btnP2.Tag = ""
        Me.btnP2.UseVisualStyleBackColor = True
        '
        'btnP3
        '
        Me.btnP3.Location = New System.Drawing.Point(16, 77)
        Me.btnP3.Margin = New System.Windows.Forms.Padding(1, 1, 1, 1)
        Me.btnP3.Name = "btnP3"
        Me.btnP3.Size = New System.Drawing.Size(41, 39)
        Me.btnP3.TabIndex = 5
        Me.btnP3.Tag = ""
        Me.btnP3.UseVisualStyleBackColor = True
        '
        'btnP4
        '
        Me.btnP4.Location = New System.Drawing.Point(71, 77)
        Me.btnP4.Margin = New System.Windows.Forms.Padding(1, 1, 1, 1)
        Me.btnP4.Name = "btnP4"
        Me.btnP4.Size = New System.Drawing.Size(41, 39)
        Me.btnP4.TabIndex = 6
        Me.btnP4.Tag = ""
        Me.btnP4.UseVisualStyleBackColor = True
        '
        'btnP5
        '
        Me.btnP5.Location = New System.Drawing.Point(127, 77)
        Me.btnP5.Margin = New System.Windows.Forms.Padding(1, 1, 1, 1)
        Me.btnP5.Name = "btnP5"
        Me.btnP5.Size = New System.Drawing.Size(41, 39)
        Me.btnP5.TabIndex = 7
        Me.btnP5.Tag = ""
        Me.btnP5.UseVisualStyleBackColor = True
        '
        'btnP6
        '
        Me.btnP6.Location = New System.Drawing.Point(16, 136)
        Me.btnP6.Margin = New System.Windows.Forms.Padding(1, 1, 1, 1)
        Me.btnP6.Name = "btnP6"
        Me.btnP6.Size = New System.Drawing.Size(41, 39)
        Me.btnP6.TabIndex = 8
        Me.btnP6.Tag = ""
        Me.btnP6.UseVisualStyleBackColor = True
        '
        'btnP7
        '
        Me.btnP7.Location = New System.Drawing.Point(71, 136)
        Me.btnP7.Margin = New System.Windows.Forms.Padding(1, 1, 1, 1)
        Me.btnP7.Name = "btnP7"
        Me.btnP7.Size = New System.Drawing.Size(41, 39)
        Me.btnP7.TabIndex = 9
        Me.btnP7.Tag = ""
        Me.btnP7.UseVisualStyleBackColor = True
        '
        'btnP8
        '
        Me.btnP8.Location = New System.Drawing.Point(127, 136)
        Me.btnP8.Margin = New System.Windows.Forms.Padding(1, 1, 1, 1)
        Me.btnP8.Name = "btnP8"
        Me.btnP8.Size = New System.Drawing.Size(41, 39)
        Me.btnP8.TabIndex = 10
        Me.btnP8.Tag = ""
        Me.btnP8.UseVisualStyleBackColor = True
        '
        'pnlBoard
        '
        Me.pnlBoard.Controls.Add(Me.btnP8)
        Me.pnlBoard.Controls.Add(Me.btnP7)
        Me.pnlBoard.Controls.Add(Me.btnP6)
        Me.pnlBoard.Controls.Add(Me.btnP5)
        Me.pnlBoard.Controls.Add(Me.btnP4)
        Me.pnlBoard.Controls.Add(Me.btnP3)
        Me.pnlBoard.Controls.Add(Me.btnP2)
        Me.pnlBoard.Controls.Add(Me.btnP1)
        Me.pnlBoard.Controls.Add(Me.btnP0)
        Me.pnlBoard.Controls.Add(Me.ShapeContainer2)
        Me.pnlBoard.Location = New System.Drawing.Point(17, 6)
        Me.pnlBoard.Margin = New System.Windows.Forms.Padding(1, 1, 1, 1)
        Me.pnlBoard.Name = "pnlBoard"
        Me.pnlBoard.Size = New System.Drawing.Size(187, 189)
        Me.pnlBoard.TabIndex = 24
        '
        'ShapeContainer2
        '
        Me.ShapeContainer2.Location = New System.Drawing.Point(0, 0)
        Me.ShapeContainer2.Margin = New System.Windows.Forms.Padding(0)
        Me.ShapeContainer2.Name = "ShapeContainer2"
        Me.ShapeContainer2.Shapes.AddRange(New Microsoft.VisualBasic.PowerPacks.Shape() {Me.LineShape4, Me.LineShape3, Me.LineShape2, Me.LineShape1})
        Me.ShapeContainer2.Size = New System.Drawing.Size(187, 189)
        Me.ShapeContainer2.TabIndex = 11
        Me.ShapeContainer2.TabStop = False
        '
        'LineShape4
        '
        Me.LineShape4.BorderWidth = 10
        Me.LineShape4.Name = "LineShape4"
        Me.LineShape4.X1 = 179
        Me.LineShape4.X2 = 3
        Me.LineShape4.Y1 = 124
        Me.LineShape4.Y2 = 124
        '
        'LineShape3
        '
        Me.LineShape3.BorderWidth = 10
        Me.LineShape3.Name = "LineShape3"
        Me.LineShape3.X1 = 181
        Me.LineShape3.X2 = 5
        Me.LineShape3.Y1 = 65
        Me.LineShape3.Y2 = 65
        '
        'LineShape2
        '
        Me.LineShape2.BorderWidth = 10
        Me.LineShape2.Name = "LineShape2"
        Me.LineShape2.X1 = 119
        Me.LineShape2.X2 = 119
        Me.LineShape2.Y1 = 9
        Me.LineShape2.Y2 = 184
        '
        'LineShape1
        '
        Me.LineShape1.BorderWidth = 10
        Me.LineShape1.Name = "LineShape1"
        Me.LineShape1.X1 = 64
        Me.LineShape1.X2 = 64
        Me.LineShape1.Y1 = 8
        Me.LineShape1.Y2 = 183
        '
        'frmServer
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(633, 376)
        Me.Controls.Add(Me.lblWinner)
        Me.Controls.Add(Me.pnlBoard)
        Me.Controls.Add(Me.pnlSetUp)
        Me.Controls.Add(Me.btnStopServer)
        Me.Controls.Add(Me.btnStartServer)
        Me.Controls.Add(Me.lblPort)
        Me.Controls.Add(Me.txtPort)
        Me.Controls.Add(Me.txtLog)
        Me.Margin = New System.Windows.Forms.Padding(1, 1, 1, 1)
        Me.Name = "frmServer"
        Me.Text = "Server - Tic Tac Toe"
        Me.gbxPlayer.ResumeLayout(False)
        Me.gbxPlayer.PerformLayout()
        Me.gbxFirst.ResumeLayout(False)
        Me.gbxFirst.PerformLayout()
        Me.pnlSetUp.ResumeLayout(False)
        Me.pnlBoard.ResumeLayout(False)
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents txtLog As TextBox
    Friend WithEvents txtPort As TextBox
    Friend WithEvents lblPort As Label
    Friend WithEvents btnStartServer As Button
    Friend WithEvents btnStopServer As Button
    Friend WithEvents gbxPlayer As GroupBox
    Friend WithEvents rbtnO As RadioButton
    Friend WithEvents rbtnX As RadioButton
    Friend WithEvents gbxFirst As GroupBox
    Friend WithEvents rbtnOFirst As RadioButton
    Friend WithEvents rbtnXFirst As RadioButton
    Friend WithEvents btnSubmitStart As Button
    Friend WithEvents pnlSetUp As Panel
    Friend WithEvents btnP0 As Button
    Friend WithEvents btnP1 As Button
    Friend WithEvents btnP2 As Button
    Friend WithEvents btnP3 As Button
    Friend WithEvents btnP4 As Button
    Friend WithEvents btnP5 As Button
    Friend WithEvents btnP6 As Button
    Friend WithEvents btnP7 As Button
    Friend WithEvents btnP8 As Button
    Friend WithEvents pnlBoard As Panel
    Friend WithEvents lblWinner As Label
    Friend WithEvents ShapeContainer2 As PowerPacks.ShapeContainer
    Friend WithEvents LineShape4 As PowerPacks.LineShape
    Friend WithEvents LineShape3 As PowerPacks.LineShape
    Friend WithEvents LineShape2 As PowerPacks.LineShape
    Friend WithEvents LineShape1 As PowerPacks.LineShape
End Class
