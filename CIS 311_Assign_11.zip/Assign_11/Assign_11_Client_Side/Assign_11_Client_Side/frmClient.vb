﻿'------------------------------------------------------------
'-                 File Name : frmClient.vb                 - 
'-                Part of Project: Assign 11                -
'------------------------------------------------------------
'-                Written By: Robert Zinger                 -
'-                Written On: 04/25/2018                    -
'------------------------------------------------------------
'- File Purpose:                                            -
'- This file contains the client side of the tic tac toe    -
'- game, it uses a server, client, protocol and a board to  -
'- play the game tic tac toe                                -
'------------------------------------------------------------
'- Program Purpose:                                         -
'-                                                          -
'- This program allows users to play tic tac toe with one   -
'- another using a server/client based communication        -
'------------------------------------------------------------
'- Global Variable Dictionary:                              -
'- NetReader - binary reader that gets data from the client -
'- NetWriter - binary writer that writes to the client      -
'- GamePlay - char array of the clients game play           -
'- OtherPlayerLetter - keeps track of other player's letter -
'- SendToServer - char array thats sent to server           -
'- Move - keeps track of whos turn it is                    -
'- NetStream - allows the server and client to talk         -
'- ServerConnection - server's socket                       -
'- tcpClient - allows client to get/write data as a client  -
'- thdData - makes a thread to allows wait time until the   -
'-      client writes to the server                         -
'------------------------------------------------------------
Imports System.ComponentModel
Imports System.IO
Imports System.Net.Sockets
Imports System.Threading
Public Class frmClient
    Dim tcpClient As TcpClient
    Dim nsNetStream As NetworkStream
    Dim bwNetWriter As BinaryWriter
    Dim brNetReader As BinaryReader
    Dim thdData As Thread
    Dim charMyLetter As Char
    Dim charSendToServer(8) As Char
    Dim charGamePlay(8) As Char
    Dim intMove As Integer = 1
    Dim charOtherPlayerLetter As Char

    '------------------------------------------------------------
    '-             Subprogram Name: frmClient_Load              -
    '------------------------------------------------------------
    '-                Written By: Robert Zinger                 -
    '-                Written On: 04/25/2018                    -
    '------------------------------------------------------------
    '- Subprogram Purpose:                                      -
    '-                                                          -
    '- This subroutine is called when the form loads and starts -
    '- the form in the default settings                         -
    '------------------------------------------------------------
    '- Parameter Dictionary:                                    -
    '- sender – Identifies which particular control raised the  –
    '-          click event                                     - 
    '- e – Holds the EventArgs object sent to the routine       -
    '------------------------------------------------------------
    '- Local Variable Dictionary:                               -
    '- (None)                                                   -
    '------------------------------------------------------------
    Private Sub frmClient_Load(sender As Object, e As EventArgs) Handles Me.Load
        pnlBoard.Enabled = False
        btnStartClient.Enabled = True
        btnStopClient.Enabled = False
        CheckForIllegalCrossThreadCalls = False
        txtAddress.Text = "127.0.0.1"
        txtPort.Text = 1000
        lblWinner.Text = Nothing
    End Sub

    '------------------------------------------------------------
    '-            Subprogram Name: btnStartClient_Click         -
    '------------------------------------------------------------
    '-                Written By: Robert Zinger                 -
    '-                Written On: 04/25/2018                    -
    '------------------------------------------------------------
    '- Subprogram Purpose:                                      -
    '-                                                          -
    '- This subroutine is called when the user hits the start   -
    '- connection button, starting the client with all the      -
    '- default properties, and how the server decided to assign -
    '- the letters                                              -
    '------------------------------------------------------------
    '- Parameter Dictionary:                                    -
    '- sender – Identifies which particular control raised the  –
    '-          click event                                     - 
    '- e – Holds the EventArgs object sent to the routine       -
    '------------------------------------------------------------
    '- Local Variable Dictionary:                               -
    '- (None)                                                   -
    '------------------------------------------------------------
    Private Sub btnStartClient_Click(sender As Object, e As EventArgs) Handles btnStartClient.Click
        ReDim charSendToServer(8)
        ReDim charGamePlay(8)
        lblWinner.Text = Nothing
        txtLog.Clear()
        Try
            txtAddress.ReadOnly = True
            txtPort.ReadOnly = True
            txtLog.Text &= "Attempting Connection" & vbCrLf
            tcpClient = New TcpClient
            tcpClient.Connect(txtAddress.Text, CInt(txtPort.Text))
            nsNetStream = tcpClient.GetStream()
            bwNetWriter = New BinaryWriter(nsNetStream)
            brNetReader = New BinaryReader(nsNetStream)
            txtLog.Text &= "Network reader/writer created" & vbCrLf
            btnStartClient.Enabled = False
            btnStopClient.Enabled = True
            txtLog.Text &= "Preparing to watch for data" & vbCrLf
            thdData = New Thread(AddressOf GetDataFromServer)
            thdData.Start()
        Catch IOEx As IOException
            txtLog.Text &= "Error in setting up client" & vbCrLf
        Catch socketEx As SocketException
            txtLog.Text &= "Cannot find server, try again later"
        End Try
    End Sub

    '------------------------------------------------------------
    '-             Subprogram Name: setUpFirstMove              -
    '------------------------------------------------------------
    '-                Written By: Robert Zinger                 -
    '-                Written On: 04/25/2018                    -
    '------------------------------------------------------------
    '- Subprogram Purpose:                                      -
    '-                                                          -
    '- This subroutine is called when the server sends the info -
    '- on who goes first and what letter the client is          -
    '------------------------------------------------------------
    '- Parameter Dictionary:                                    -
    '- Data - what the server writes to the client on how to set-
    '-      up the game                                         -
    '------------------------------------------------------------
    '- Local Variable Dictionary:                               -
    '- (None)                                                   -
    '------------------------------------------------------------
    Sub setUpFirstMove(strData)
        If (strData(1) = "X") Then
            charMyLetter = "O"
            charOtherPlayerLetter = "X"
        Else
            charMyLetter = "X"
            charOtherPlayerLetter = "O"
        End If
        If (strData(2) = charMyLetter) Then
            intMove += 1
            Call myTurn(intMove)
        Else
            Call myTurn(intMove)
        End If
        Me.Text = "Client - Tic Tac Toe - " & charMyLetter
    End Sub

    '------------------------------------------------------------
    '-              Subprogram Name: btnP0_Click                -
    '------------------------------------------------------------
    '-                Written By: Robert Zinger                 -
    '-                Written On: 04/25/2018                    -
    '------------------------------------------------------------
    '- Subprogram Purpose:                                      -
    '-                                                          -
    '- This subroutine is called when the user clicks on the    -
    '- gameboard postion, setting that button to the client's   -
    '- letter and disabling it from being clicked again, and    -
    '- sending the string to the server                         -
    '------------------------------------------------------------
    '- Parameter Dictionary:                                    -
    '- sender – Identifies which particular control raised the  –
    '-          click event                                     - 
    '- e – Holds the EventArgs object sent to the routine       -
    '------------------------------------------------------------
    '- Local Variable Dictionary:                               -
    '- (None)                                                   -
    '------------------------------------------------------------
    Private Sub btnP0_Click(sender As Object, e As EventArgs) Handles btnP0.Click
        charSendToServer(0) = "1"
        btnP0.Text = charMyLetter
        btnP0.Enabled = False
        Call writeToServer()
    End Sub

    '------------------------------------------------------------
    '-              Subprogram Name: btnP1_Click                -
    '------------------------------------------------------------
    '-                Written By: Robert Zinger                 -
    '-                Written On: 04/25/2018                    -
    '------------------------------------------------------------
    '- Subprogram Purpose:                                      -
    '-                                                          -
    '- This subroutine is called when the user clicks on the    -
    '- gameboard postion, setting that button to the client's   -
    '- letter and disabling it from being clicked again, and    -
    '- sending the string to the server                         -
    '------------------------------------------------------------
    '- Parameter Dictionary:                                    -
    '- sender – Identifies which particular control raised the  –
    '-          click event                                     - 
    '- e – Holds the EventArgs object sent to the routine       -
    '------------------------------------------------------------
    '- Local Variable Dictionary:                               -
    '- (None)                                                   -
    '------------------------------------------------------------
    Private Sub btnP1_Click(sender As Object, e As EventArgs) Handles btnP1.Click
        charSendToServer(1) = "1"
        btnP1.Text = charMyLetter
        btnP1.Enabled = False
        Call writeToServer()
    End Sub

    '------------------------------------------------------------
    '-              Subprogram Name: btnP2_Click                -
    '------------------------------------------------------------
    '-                Written By: Robert Zinger                 -
    '-                Written On: 04/25/2018                    -
    '------------------------------------------------------------
    '- Subprogram Purpose:                                      -
    '-                                                          -
    '- This subroutine is called when the user clicks on the    -
    '- gameboard postion, setting that button to the client's   -
    '- letter and disabling it from being clicked again, and    -
    '- sending the string to the server                         -
    '------------------------------------------------------------
    '- Parameter Dictionary:                                    -
    '- sender – Identifies which particular control raised the  –
    '-          click event                                     - 
    '- e – Holds the EventArgs object sent to the routine       -
    '------------------------------------------------------------
    '- Local Variable Dictionary:                               -
    '- (None)                                                   -
    '------------------------------------------------------------
    Private Sub btnP2_Click(sender As Object, e As EventArgs) Handles btnP2.Click
        charSendToServer(2) = "1"
        btnP2.Text = charMyLetter
        btnP2.Enabled = False
        Call writeToServer()
    End Sub

    '------------------------------------------------------------
    '-              Subprogram Name: btnP3_Click                -
    '------------------------------------------------------------
    '-                Written By: Robert Zinger                 -
    '-                Written On: 04/25/2018                    -
    '------------------------------------------------------------
    '- Subprogram Purpose:                                      -
    '-                                                          -
    '- This subroutine is called when the user clicks on the    -
    '- gameboard postion, setting that button to the client's   -
    '- letter and disabling it from being clicked again, and    -
    '- sending the string to the server                         -
    '------------------------------------------------------------
    '- Parameter Dictionary:                                    -
    '- sender – Identifies which particular control raised the  –
    '-          click event                                     - 
    '- e – Holds the EventArgs object sent to the routine       -
    '------------------------------------------------------------
    '- Local Variable Dictionary:                               -
    '- (None)                                                   -
    '------------------------------------------------------------
    Private Sub btnP3_Click(sender As Object, e As EventArgs) Handles btnP3.Click
        charSendToServer(3) = "1"
        btnP3.Text = charMyLetter
        btnP3.Enabled = False
        Call writeToServer()
    End Sub

    '------------------------------------------------------------
    '-              Subprogram Name: btnP4_Click                -
    '------------------------------------------------------------
    '-                Written By: Robert Zinger                 -
    '-                Written On: 04/25/2018                    -
    '------------------------------------------------------------
    '- Subprogram Purpose:                                      -
    '-                                                          -
    '- This subroutine is called when the user clicks on the    -
    '- gameboard postion, setting that button to the client's   -
    '- letter and disabling it from being clicked again, and    -
    '- sending the string to the server                         -
    '------------------------------------------------------------
    '- Parameter Dictionary:                                    -
    '- sender – Identifies which particular control raised the  –
    '-          click event                                     - 
    '- e – Holds the EventArgs object sent to the routine       -
    '------------------------------------------------------------
    '- Local Variable Dictionary:                               -
    '- (None)                                                   -
    '------------------------------------------------------------
    Private Sub btnP4_Click(sender As Object, e As EventArgs) Handles btnP4.Click
        charSendToServer(4) = "1"
        btnP4.Text = charMyLetter
        btnP4.Enabled = False
        Call writeToServer()
    End Sub

    '------------------------------------------------------------
    '-              Subprogram Name: btnP5_Click                -
    '------------------------------------------------------------
    '-                Written By: Robert Zinger                 -
    '-                Written On: 04/25/2018                    -
    '------------------------------------------------------------
    '- Subprogram Purpose:                                      -
    '-                                                          -
    '- This subroutine is called when the user clicks on the    -
    '- gameboard postion, setting that button to the client's   -
    '- letter and disabling it from being clicked again, and    -
    '- sending the string to the server                         -
    '------------------------------------------------------------
    '- Parameter Dictionary:                                    -
    '- sender – Identifies which particular control raised the  –
    '-          click event                                     - 
    '- e – Holds the EventArgs object sent to the routine       -
    '------------------------------------------------------------
    '- Local Variable Dictionary:                               -
    '- (None)                                                   -
    '------------------------------------------------------------
    Private Sub btnP5_Click(sender As Object, e As EventArgs) Handles btnP5.Click
        charSendToServer(5) = "1"
        btnP5.Text = charMyLetter
        btnP5.Enabled = False
        Call writeToServer()
    End Sub

    '------------------------------------------------------------
    '-              Subprogram Name: btnP6_Click                -
    '------------------------------------------------------------
    '-                Written By: Robert Zinger                 -
    '-                Written On: 04/25/2018                    -
    '------------------------------------------------------------
    '- Subprogram Purpose:                                      -
    '-                                                          -
    '- This subroutine is called when the user clicks on the    -
    '- gameboard postion, setting that button to the client's   -
    '- letter and disabling it from being clicked again, and    -
    '- sending the string to the server                         -
    '------------------------------------------------------------
    '- Parameter Dictionary:                                    -
    '- sender – Identifies which particular control raised the  –
    '-          click event                                     - 
    '- e – Holds the EventArgs object sent to the routine       -
    '------------------------------------------------------------
    '- Local Variable Dictionary:                               -
    '- (None)                                                   -
    '------------------------------------------------------------
    Private Sub btnP6_Click(sender As Object, e As EventArgs) Handles btnP6.Click
        charSendToServer(6) = "1"
        btnP6.Text = charMyLetter
        btnP6.Enabled = False
        Call writeToServer()
    End Sub

    '------------------------------------------------------------
    '-              Subprogram Name: btnP7_Click                -
    '------------------------------------------------------------
    '-                Written By: Robert Zinger                 -
    '-                Written On: 04/25/2018                    -
    '------------------------------------------------------------
    '- Subprogram Purpose:                                      -
    '-                                                          -
    '- This subroutine is called when the user clicks on the    -
    '- gameboard postion, setting that button to the client's   -
    '- letter and disabling it from being clicked again, and    -
    '- sending the string to the server                         -
    '------------------------------------------------------------
    '- Parameter Dictionary:                                    -
    '- sender – Identifies which particular control raised the  –
    '-          click event                                     - 
    '- e – Holds the EventArgs object sent to the routine       -
    '------------------------------------------------------------
    '- Local Variable Dictionary:                               -
    '- (None)                                                   -
    '------------------------------------------------------------
    Private Sub btnP7_Click(sender As Object, e As EventArgs) Handles btnP7.Click
        charSendToServer(7) = "1"
        btnP7.Text = charMyLetter
        btnP7.Enabled = False
        Call writeToServer()
    End Sub

    '------------------------------------------------------------
    '-              Subprogram Name: btnP8_Click                -
    '------------------------------------------------------------
    '-                Written By: Robert Zinger                 -
    '-                Written On: 04/25/2018                    -
    '------------------------------------------------------------
    '- Subprogram Purpose:                                      -
    '-                                                          -
    '- This subroutine is called when the user clicks on the    -
    '- gameboard postion, setting that button to the client's   -
    '- letter and disabling it from being clicked again, and    -
    '- sending the string to the server                         -
    '------------------------------------------------------------
    '- Parameter Dictionary:                                    -
    '- sender – Identifies which particular control raised the  –
    '-          click event                                     - 
    '- e – Holds the EventArgs object sent to the routine       -
    '------------------------------------------------------------
    '- Local Variable Dictionary:                               -
    '- (None)                                                   -
    '------------------------------------------------------------
    Private Sub btnP8_Click(sender As Object, e As EventArgs) Handles btnP8.Click
        charSendToServer(8) = "1"
        btnP8.Text = charMyLetter
        btnP8.Enabled = False
        Call writeToServer()
    End Sub

    '------------------------------------------------------------
    '-                Function Name: convertTo1D                -
    '------------------------------------------------------------
    '-                Written By: Robert Zinger                 -
    '-                Written On: 04/25/2018                    -
    '------------------------------------------------------------
    '- Subprogram Purpose:                                      -
    '-                                                          -
    '- This function is called when the client needs to write   -
    '- to server, converting the gameboard into a 1D char array -
    '------------------------------------------------------------
    '- Parameter Dictionary:                                    -
    '- (None)                                                   -
    '------------------------------------------------------------
    '- Local Variable Dictionary:                               -
    '- Converted - the converted string                         -
    '------------------------------------------------------------
    '- Returns:                                                 -
    '- String – which position the client clicked on            -
    '------------------------------------------------------------
    Function convertTo1D()
        Dim strConverted = Nothing
        For intLoop = 0 To 8 Step 1
            If (charSendToServer(intLoop) = Nothing) Then
                strConverted &= " "
            ElseIf (charSendToServer(intLoop) = "1") Then
                strConverted &= charMyLetter
            End If
        Next
        Return strConverted
    End Function

    '------------------------------------------------------------
    '-              Subprogram Name: writeToServer              -
    '------------------------------------------------------------
    '-                Written By: Robert Zinger                 -
    '-                Written On: 04/25/2018                    -
    '------------------------------------------------------------
    '- Subprogram Purpose:                                      -
    '-                                                          -
    '- This subroutine is called when the user clicks on a game -
    '- board position, calling the convert function and also    -
    '- incrimenting the Move integer to tell the server its     -
    '- their turn and stops the client from clicking another    -
    '- position                                                 -
    '------------------------------------------------------------
    '- Parameter Dictionary:                                    -
    '- (None)                                                   -
    '------------------------------------------------------------
    '- Local Variable Dictionary:                               -
    '- (None)                                                   -
    '------------------------------------------------------------
    Sub writeToServer()
        intMove += 1
        Call myTurn(intMove)
        bwNetWriter.Write("P" & convertTo1D())
    End Sub

    '------------------------------------------------------------
    '-             Subprogram Name: GetDataFromServer           -
    '------------------------------------------------------------
    '-                Written By: Robert Zinger                 -
    '-                Written On: 04/25/2018                    -
    '------------------------------------------------------------
    '- Subprogram Purpose:                                      -
    '-                                                          -
    '- This subroutine is called when the server sends info to  -
    '- the client, it uses a simple protocol to know how to act -
    '- with the start of the string thats sent from the server  -
    '------------------------------------------------------------
    '- Parameter Dictionary:                                    -
    '- sender – Identifies which particular control raised the  –
    '-          click event                                     - 
    '- e – Holds the EventArgs object sent to the routine       -
    '------------------------------------------------------------
    '- Local Variable Dictionary:                               -
    '- Data - the string thats sent from the server             -
    '------------------------------------------------------------
    Sub GetDataFromServer()
        Dim strData As String
        txtLog.Text &= "Thread now active" & vbCrLf
        Call myTurn(intMove)
        Try
            Do
                strData = brNetReader.ReadString
                If (strData(0) = "S") Then
                    Call setUpFirstMove(strData)
                ElseIf (strData(0) = "P") Then
                    For intLoop = 0 To 8 Step 1
                        charGamePlay(intLoop) = strData(intLoop + 1)
                    Next
                    Call checkOtherPlayMoves(charGamePlay)
                    Call gamePlay()
                    If (checkWinPatterns(charGamePlay) = True) Then
                        bwNetWriter.Write("W" & charOtherPlayerLetter)
                    ElseIf ((checkWinPatterns(charGamePlay) = False) And intMove = 10) Then
                        bwNetWriter.Write("W" & "C")
                    End If
                ElseIf (strData(0) = "W") Then
                    lblWinner.Text = strData(1) & " Wins"
                    bwNetWriter.Write("W" & strData(1))
                    If ((strData(0) = "W") And strData(1) = "C") Then
                        lblWinner.Text = "Tie"
                    End If
                    txtLog.Text &= "From Server: " & strData & vbCrLf
                    Call DisconnectClient()
                End If
                txtLog.Text &= "From Server: " & strData & vbCrLf
            Loop While (strData <> "~~END~~")
            Call DisconnectClient()
        Catch IOEx As IOException
            txtLog.Text &= "Closing connection" & vbCrLf
            Call DisconnectClient()
        End Try
    End Sub

    '------------------------------------------------------------
    '-                Subprogram Name: gamePlay                 -
    '------------------------------------------------------------
    '-                Written By: Robert Zinger                 -
    '-                Written On: 04/25/2018                    -
    '------------------------------------------------------------
    '- Subprogram Purpose:                                      -
    '-                                                          -
    '- This subroutine is called when the server makes a move   -
    '- incrimenting the Move integer and calls myTurn to see if -
    '- its the clients or servers turn                          -
    '------------------------------------------------------------
    '- Parameter Dictionary:                                    -
    '- (None)                                                   -
    '------------------------------------------------------------
    '- Local Variable Dictionary:                               -
    '- (None)                                                   -
    '------------------------------------------------------------
    Sub gamePlay()
        intMove += 1
        Call myTurn(intMove)
    End Sub

    '------------------------------------------------------------
    '-                 Subprogram Name: myTurn                  -
    '------------------------------------------------------------
    '-                Written By: Robert Zinger                 -
    '-                Written On: 04/25/2018                    -
    '------------------------------------------------------------
    '- Subprogram Purpose:                                      -
    '-                                                          -
    '- This subroutine is called when a move is made, then      -
    '- figures out if its the clients turn or servers, then     -
    '- enables the board to whos turn it is                     -
    '------------------------------------------------------------
    '- Parameter Dictionary:                                    -
    '- move - integer of what move it is                        -
    '------------------------------------------------------------
    '- Local Variable Dictionary:                               -
    '- (None)                                                   -
    '------------------------------------------------------------
    Sub myTurn(move)
        If (move Mod 2 = 0) Then
            pnlBoard.Enabled = True
        Else
            pnlBoard.Enabled = False
        End If
    End Sub

    '------------------------------------------------------------
    '-           Subprogram Name: checkOtherPlayMoves           -
    '------------------------------------------------------------
    '-                Written By: Robert Zinger                 -
    '-                Written On: 04/25/2018                    -
    '------------------------------------------------------------
    '- Subprogram Purpose:                                      -
    '-                                                          -
    '- This subroutine is called when the client writes to the  -
    '- server, and then disables the position the client chose  -
    '- last                                                     -
    '------------------------------------------------------------
    '- Parameter Dictionary:                                    -
    '- currentMoves - char array thats sent from the server     -
    '------------------------------------------------------------
    '- Local Variable Dictionary:                               -
    '- (None)                                                   -
    '------------------------------------------------------------
    Sub checkOtherPlayMoves(currentMoves() As Char)
        If (currentMoves(0) = charOtherPlayerLetter) Then
            btnP0.Text = charOtherPlayerLetter
            btnP0.Enabled = False
        End If
        If (currentMoves(1) = charOtherPlayerLetter) Then
            btnP1.Text = charOtherPlayerLetter
            btnP1.Enabled = False
        End If
        If (currentMoves(2) = charOtherPlayerLetter) Then
            btnP2.Text = charOtherPlayerLetter
            btnP2.Enabled = False
        End If
        If (currentMoves(3) = charOtherPlayerLetter) Then
            btnP3.Text = charOtherPlayerLetter
            btnP3.Enabled = False
        End If
        If (currentMoves(4) = charOtherPlayerLetter) Then
            btnP4.Text = charOtherPlayerLetter
            btnP4.Enabled = False
        End If
        If (currentMoves(5) = charOtherPlayerLetter) Then
            btnP5.Text = charOtherPlayerLetter
            btnP5.Enabled = False
        End If
        If (currentMoves(6) = charOtherPlayerLetter) Then
            btnP6.Text = charOtherPlayerLetter
            btnP6.Enabled = False
        End If
        If (currentMoves(7) = charOtherPlayerLetter) Then
            btnP7.Text = charOtherPlayerLetter
            btnP7.Enabled = False
        End If
        If (currentMoves(8) = charOtherPlayerLetter) Then
            btnP8.Text = charOtherPlayerLetter
            btnP8.Enabled = False
        End If
    End Sub

    '------------------------------------------------------------
    '-             Subprogram Name: checkWinPatterns            -
    '------------------------------------------------------------
    '-                Written By: Robert Zinger                 -
    '-                Written On: 04/25/2018                    -
    '------------------------------------------------------------
    '- Subprogram Purpose:                                      -
    '-                                                          -
    '- This subroutine is called when the client writes to the  -
    '- server, and checks all the possible win patterns         -
    '------------------------------------------------------------
    '- Parameter Dictionary:                                    -
    '- currentMoves - char array thats sent from the server     -
    '------------------------------------------------------------
    '- Local Variable Dictionary:                               -
    '- (None)                                                   -
    '------------------------------------------------------------
    Function checkWinPatterns(currentMoves() As Char)
        If ((currentMoves(0) = charOtherPlayerLetter) And (currentMoves(1) = charOtherPlayerLetter) And (currentMoves(2) = charOtherPlayerLetter)) Then
            Return True
        ElseIf ((currentMoves(3) = charOtherPlayerLetter) And (currentMoves(4) = charOtherPlayerLetter) And (currentMoves(5) = charOtherPlayerLetter)) Then
            Return True
        ElseIf ((currentMoves(6) = charOtherPlayerLetter) And (currentMoves(7) = charOtherPlayerLetter) And (currentMoves(8) = charOtherPlayerLetter)) Then
            Return True
        ElseIf ((currentMoves(0) = charOtherPlayerLetter) And (currentMoves(3) = charOtherPlayerLetter) And (currentMoves(6) = charOtherPlayerLetter)) Then
            Return True
        ElseIf ((currentMoves(0) = charOtherPlayerLetter) And (currentMoves(3) = charOtherPlayerLetter) And (currentMoves(6) = charOtherPlayerLetter)) Then
            Return True
        ElseIf ((currentMoves(1) = charOtherPlayerLetter) And (currentMoves(4) = charOtherPlayerLetter) And (currentMoves(7) = charOtherPlayerLetter)) Then
            Return True
        ElseIf ((currentMoves(2) = charOtherPlayerLetter) And (currentMoves(5) = charOtherPlayerLetter) And (currentMoves(8) = charOtherPlayerLetter)) Then
            Return True
        ElseIf ((currentMoves(0) = charOtherPlayerLetter) And (currentMoves(4) = charOtherPlayerLetter) And (currentMoves(8) = charOtherPlayerLetter)) Then
            Return True
        ElseIf ((currentMoves(2) = charOtherPlayerLetter) And (currentMoves(4) = charOtherPlayerLetter) And (currentMoves(6) = charOtherPlayerLetter)) Then
            Return True
        End If
        Return False
    End Function

    '------------------------------------------------------------
    '-            Subprogram Name: btnStopClient_Click          -
    '------------------------------------------------------------
    '-                Written By: Robert Zinger                 -
    '-                Written On: 04/25/2018                    -
    '------------------------------------------------------------
    '- Subprogram Purpose:                                      -
    '-                                                          -
    '- This subroutine is called when the user clicks the stop  -
    '- client button, calling the sub that closes the client and-
    '- resets everything to the default state                   -
    '------------------------------------------------------------
    '- Parameter Dictionary:                                    -
    '- sender – Identifies which particular control raised the  –
    '-          click event                                     - 
    '- e – Holds the EventArgs object sent to the routine       -
    '------------------------------------------------------------
    '- Local Variable Dictionary:                               -
    '- (None)                                                   -
    '------------------------------------------------------------
    Private Sub btnStopClient_Click(sender As Object, e As EventArgs) Handles btnStopClient.Click
        Call DisconnectClient()
    End Sub

    '------------------------------------------------------------
    '-            Subprogram Name: DisconnectClient             -
    '------------------------------------------------------------
    '-                Written By: Robert Zinger                 -
    '-                Written On: 04/25/2018                    -
    '------------------------------------------------------------
    '- Subprogram Purpose:                                      -
    '-                                                          -
    '- This subroutine is called when the client should be      -
    '- stopped, reseting everything to allow the next connection-
    '- to be started                                            -
    '------------------------------------------------------------
    '- Parameter Dictionary:                                    -
    '- sender – Identifies which particular control raised the  –
    '-          click event                                     - 
    '- e – Holds the EventArgs object sent to the routine       -
    '------------------------------------------------------------
    '- Local Variable Dictionary:                               -
    '- (None)                                                   -
    '------------------------------------------------------------
    Sub DisconnectClient()
        pnlBoard.Enabled = False
        btnStartClient.Enabled = True
        btnStopClient.Enabled = False
        intMove = 1
        Call clearBtns()
        txtLog.Text &= vbCrLf & "Disconnecting from server" & vbCrLf
        Try
            bwNetWriter.Write("~~END~~")
        Catch ex As Exception
        End Try
        Try
            bwNetWriter.Close()
            brNetReader.Close()
            nsNetStream.Close()
            tcpClient.Close()
            bwNetWriter = Nothing
            brNetReader = Nothing
            nsNetStream = Nothing
            tcpClient = Nothing
            Try
                thdData.Abort()
            Catch ex As Exception
            End Try
        Catch ex As Exception
        Finally
            txtLog.Text &= "Disconnected" & vbCrLf
        End Try
    End Sub

    '------------------------------------------------------------
    '-               Subprogram Name: clearBtns                 -
    '------------------------------------------------------------
    '-                Written By: Robert Zinger                 -
    '-                Written On: 04/25/2018                    -
    '------------------------------------------------------------
    '- Subprogram Purpose:                                      -
    '-                                                          -
    '- This subroutine is called when the game board needs to be-
    '- reset                                                    -
    '------------------------------------------------------------
    '- Parameter Dictionary:                                    -
    '- (None)                                                   -
    '------------------------------------------------------------
    '- Local Variable Dictionary:                               -
    '- (None)                                                   -
    '------------------------------------------------------------
    Sub clearBtns()
        btnP0.Text = Nothing
        btnP0.Enabled = True
        btnP1.Text = Nothing
        btnP1.Enabled = True
        btnP2.Text = Nothing
        btnP2.Enabled = True
        btnP3.Text = Nothing
        btnP3.Enabled = True
        btnP4.Text = Nothing
        btnP4.Enabled = True
        btnP5.Text = Nothing
        btnP5.Enabled = True
        btnP6.Text = Nothing
        btnP6.Enabled = True
        btnP7.Text = Nothing
        btnP7.Enabled = True
        btnP8.Text = Nothing
        btnP8.Enabled = True
    End Sub

    '------------------------------------------------------------
    '-              Subprogram Name: frmClient_Closing          -
    '------------------------------------------------------------
    '-                Written By: Robert Zinger                 -
    '-                Written On: 04/25/2018                    -
    '------------------------------------------------------------
    '- Subprogram Purpose:                                      -
    '-                                                          -
    '- This subroutine is called when the client should be      -
    '- stopped as the form is closing                           -
    '------------------------------------------------------------
    '- Parameter Dictionary:                                    -
    '- sender – Identifies which particular control raised the  –
    '-          click event                                     - 
    '- e – Holds the EventArgs object sent to the routine       -
    '------------------------------------------------------------
    '- Local Variable Dictionary:                               -
    '- (None)                                                   -
    '------------------------------------------------------------
    Private Sub frmClient_Closing(sender As Object, e As CancelEventArgs) Handles Me.Closing
        Call DisconnectClient()
    End Sub
End Class