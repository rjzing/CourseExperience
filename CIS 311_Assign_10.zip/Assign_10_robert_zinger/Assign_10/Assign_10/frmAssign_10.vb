﻿'------------------------------------------------------------
'-                File Name : frmAssign_10.vb               - 
'-                Part of Project: Assign 10                -
'------------------------------------------------------------
'-                Written By: Robert Zinger                 -
'-                Written On: 04/18/2018                    -
'------------------------------------------------------------
'- File Purpose:                                            -
'- This file container to show the conClock control working -
'------------------------------------------------------------
'- Program Purpose:                                         -
'-                                                          -
'- This program shows the conClock on a working form        -
'------------------------------------------------------------
'- Global Variable Dictionary:                              -
'- (None)                                                   -
'------------------------------------------------------------
Public Class frmAssign_10

End Class
