﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmCalcChild
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.lblVal1 = New System.Windows.Forms.Label()
        Me.lblVal2 = New System.Windows.Forms.Label()
        Me.lblRes = New System.Windows.Forms.Label()
        Me.lblVal1Bin = New System.Windows.Forms.Label()
        Me.lblVal2Bin = New System.Windows.Forms.Label()
        Me.lblResBin = New System.Windows.Forms.Label()
        Me.txtVal1Bin = New System.Windows.Forms.TextBox()
        Me.txtVal2Bin = New System.Windows.Forms.TextBox()
        Me.txtResBin = New System.Windows.Forms.TextBox()
        Me.lblVal1Dec = New System.Windows.Forms.Label()
        Me.lblVal2Dec = New System.Windows.Forms.Label()
        Me.lblResDec = New System.Windows.Forms.Label()
        Me.txtVal1Dec = New System.Windows.Forms.TextBox()
        Me.txtVal2Dec = New System.Windows.Forms.TextBox()
        Me.txtResDec = New System.Windows.Forms.TextBox()
        Me.lblVal1Hex = New System.Windows.Forms.Label()
        Me.lblVal2Hex = New System.Windows.Forms.Label()
        Me.lblResHex = New System.Windows.Forms.Label()
        Me.txtVal1Hex = New System.Windows.Forms.TextBox()
        Me.txtVal2Hex = New System.Windows.Forms.TextBox()
        Me.txtResHex = New System.Windows.Forms.TextBox()
        Me.btnHexA = New System.Windows.Forms.Button()
        Me.btnHexB = New System.Windows.Forms.Button()
        Me.btnHexC = New System.Windows.Forms.Button()
        Me.btnHexD = New System.Windows.Forms.Button()
        Me.btnHexE = New System.Windows.Forms.Button()
        Me.btnHexF = New System.Windows.Forms.Button()
        Me.btn0 = New System.Windows.Forms.Button()
        Me.btn1 = New System.Windows.Forms.Button()
        Me.btn2 = New System.Windows.Forms.Button()
        Me.btn3 = New System.Windows.Forms.Button()
        Me.btn4 = New System.Windows.Forms.Button()
        Me.btn5 = New System.Windows.Forms.Button()
        Me.btn6 = New System.Windows.Forms.Button()
        Me.btn7 = New System.Windows.Forms.Button()
        Me.btn8 = New System.Windows.Forms.Button()
        Me.btn9 = New System.Windows.Forms.Button()
        Me.btnConvert = New System.Windows.Forms.Button()
        Me.btnClearVal1 = New System.Windows.Forms.Button()
        Me.btnClearVal2 = New System.Windows.Forms.Button()
        Me.btnClearRes = New System.Windows.Forms.Button()
        Me.btnAnd = New System.Windows.Forms.Button()
        Me.btnOr = New System.Windows.Forms.Button()
        Me.btnXor = New System.Windows.Forms.Button()
        Me.btnNotVal1 = New System.Windows.Forms.Button()
        Me.btnClearAllVal = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'lblVal1
        '
        Me.lblVal1.AutoSize = True
        Me.lblVal1.Location = New System.Drawing.Point(304, 9)
        Me.lblVal1.Name = "lblVal1"
        Me.lblVal1.Size = New System.Drawing.Size(124, 37)
        Me.lblVal1.TabIndex = 0
        Me.lblVal1.Text = "Value 1"
        '
        'lblVal2
        '
        Me.lblVal2.AutoSize = True
        Me.lblVal2.Location = New System.Drawing.Point(1208, 9)
        Me.lblVal2.Name = "lblVal2"
        Me.lblVal2.Size = New System.Drawing.Size(126, 37)
        Me.lblVal2.TabIndex = 1
        Me.lblVal2.Text = "Value 2"
        '
        'lblRes
        '
        Me.lblRes.AutoSize = True
        Me.lblRes.Location = New System.Drawing.Point(1953, 9)
        Me.lblRes.Name = "lblRes"
        Me.lblRes.Size = New System.Drawing.Size(106, 37)
        Me.lblRes.TabIndex = 2
        Me.lblRes.Text = "Result"
        '
        'lblVal1Bin
        '
        Me.lblVal1Bin.AutoSize = True
        Me.lblVal1Bin.Location = New System.Drawing.Point(58, 86)
        Me.lblVal1Bin.Name = "lblVal1Bin"
        Me.lblVal1Bin.Size = New System.Drawing.Size(107, 37)
        Me.lblVal1Bin.TabIndex = 3
        Me.lblVal1Bin.Text = "Binary"
        '
        'lblVal2Bin
        '
        Me.lblVal2Bin.AutoSize = True
        Me.lblVal2Bin.Location = New System.Drawing.Point(862, 86)
        Me.lblVal2Bin.Name = "lblVal2Bin"
        Me.lblVal2Bin.Size = New System.Drawing.Size(107, 37)
        Me.lblVal2Bin.TabIndex = 4
        Me.lblVal2Bin.Text = "Binary"
        '
        'lblResBin
        '
        Me.lblResBin.AutoSize = True
        Me.lblResBin.Location = New System.Drawing.Point(1688, 86)
        Me.lblResBin.Name = "lblResBin"
        Me.lblResBin.Size = New System.Drawing.Size(107, 37)
        Me.lblResBin.TabIndex = 5
        Me.lblResBin.Text = "Binary"
        '
        'txtVal1Bin
        '
        Me.txtVal1Bin.Location = New System.Drawing.Point(65, 126)
        Me.txtVal1Bin.MaxLength = 32
        Me.txtVal1Bin.Name = "txtVal1Bin"
        Me.txtVal1Bin.ReadOnly = True
        Me.txtVal1Bin.Size = New System.Drawing.Size(748, 44)
        Me.txtVal1Bin.TabIndex = 6
        '
        'txtVal2Bin
        '
        Me.txtVal2Bin.Location = New System.Drawing.Point(869, 126)
        Me.txtVal2Bin.MaxLength = 32
        Me.txtVal2Bin.Name = "txtVal2Bin"
        Me.txtVal2Bin.ReadOnly = True
        Me.txtVal2Bin.Size = New System.Drawing.Size(748, 44)
        Me.txtVal2Bin.TabIndex = 7
        '
        'txtResBin
        '
        Me.txtResBin.Location = New System.Drawing.Point(1695, 126)
        Me.txtResBin.Name = "txtResBin"
        Me.txtResBin.ReadOnly = True
        Me.txtResBin.Size = New System.Drawing.Size(748, 44)
        Me.txtResBin.TabIndex = 8
        '
        'lblVal1Dec
        '
        Me.lblVal1Dec.AutoSize = True
        Me.lblVal1Dec.Location = New System.Drawing.Point(58, 246)
        Me.lblVal1Dec.Name = "lblVal1Dec"
        Me.lblVal1Dec.Size = New System.Drawing.Size(132, 37)
        Me.lblVal1Dec.TabIndex = 9
        Me.lblVal1Dec.Text = "Decimal"
        '
        'lblVal2Dec
        '
        Me.lblVal2Dec.AutoSize = True
        Me.lblVal2Dec.Location = New System.Drawing.Point(862, 246)
        Me.lblVal2Dec.Name = "lblVal2Dec"
        Me.lblVal2Dec.Size = New System.Drawing.Size(132, 37)
        Me.lblVal2Dec.TabIndex = 10
        Me.lblVal2Dec.Text = "Decimal"
        '
        'lblResDec
        '
        Me.lblResDec.AutoSize = True
        Me.lblResDec.Location = New System.Drawing.Point(1688, 246)
        Me.lblResDec.Name = "lblResDec"
        Me.lblResDec.Size = New System.Drawing.Size(132, 37)
        Me.lblResDec.TabIndex = 11
        Me.lblResDec.Text = "Decimal"
        '
        'txtVal1Dec
        '
        Me.txtVal1Dec.AccessibleName = "txtVal1Dec"
        Me.txtVal1Dec.Location = New System.Drawing.Point(65, 286)
        Me.txtVal1Dec.Name = "txtVal1Dec"
        Me.txtVal1Dec.ReadOnly = True
        Me.txtVal1Dec.Size = New System.Drawing.Size(748, 44)
        Me.txtVal1Dec.TabIndex = 12
        '
        'txtVal2Dec
        '
        Me.txtVal2Dec.Location = New System.Drawing.Point(869, 286)
        Me.txtVal2Dec.Name = "txtVal2Dec"
        Me.txtVal2Dec.ReadOnly = True
        Me.txtVal2Dec.Size = New System.Drawing.Size(748, 44)
        Me.txtVal2Dec.TabIndex = 13
        '
        'txtResDec
        '
        Me.txtResDec.Location = New System.Drawing.Point(1695, 286)
        Me.txtResDec.Name = "txtResDec"
        Me.txtResDec.ReadOnly = True
        Me.txtResDec.Size = New System.Drawing.Size(748, 44)
        Me.txtResDec.TabIndex = 14
        '
        'lblVal1Hex
        '
        Me.lblVal1Hex.AutoSize = True
        Me.lblVal1Hex.Location = New System.Drawing.Point(58, 394)
        Me.lblVal1Hex.Name = "lblVal1Hex"
        Me.lblVal1Hex.Size = New System.Drawing.Size(72, 37)
        Me.lblVal1Hex.TabIndex = 15
        Me.lblVal1Hex.Text = "Hex"
        '
        'lblVal2Hex
        '
        Me.lblVal2Hex.AutoSize = True
        Me.lblVal2Hex.Location = New System.Drawing.Point(862, 394)
        Me.lblVal2Hex.Name = "lblVal2Hex"
        Me.lblVal2Hex.Size = New System.Drawing.Size(72, 37)
        Me.lblVal2Hex.TabIndex = 16
        Me.lblVal2Hex.Text = "Hex"
        '
        'lblResHex
        '
        Me.lblResHex.AutoSize = True
        Me.lblResHex.Location = New System.Drawing.Point(1688, 394)
        Me.lblResHex.Name = "lblResHex"
        Me.lblResHex.Size = New System.Drawing.Size(72, 37)
        Me.lblResHex.TabIndex = 17
        Me.lblResHex.Text = "Hex"
        '
        'txtVal1Hex
        '
        Me.txtVal1Hex.Location = New System.Drawing.Point(65, 434)
        Me.txtVal1Hex.Name = "txtVal1Hex"
        Me.txtVal1Hex.ReadOnly = True
        Me.txtVal1Hex.Size = New System.Drawing.Size(748, 44)
        Me.txtVal1Hex.TabIndex = 18
        '
        'txtVal2Hex
        '
        Me.txtVal2Hex.Location = New System.Drawing.Point(869, 434)
        Me.txtVal2Hex.Name = "txtVal2Hex"
        Me.txtVal2Hex.ReadOnly = True
        Me.txtVal2Hex.Size = New System.Drawing.Size(748, 44)
        Me.txtVal2Hex.TabIndex = 19
        '
        'txtResHex
        '
        Me.txtResHex.Location = New System.Drawing.Point(1695, 434)
        Me.txtResHex.Name = "txtResHex"
        Me.txtResHex.ReadOnly = True
        Me.txtResHex.Size = New System.Drawing.Size(748, 44)
        Me.txtResHex.TabIndex = 20
        '
        'btnHexA
        '
        Me.btnHexA.Enabled = False
        Me.btnHexA.Location = New System.Drawing.Point(114, 551)
        Me.btnHexA.Name = "btnHexA"
        Me.btnHexA.Size = New System.Drawing.Size(76, 72)
        Me.btnHexA.TabIndex = 21
        Me.btnHexA.Text = "A"
        Me.btnHexA.UseVisualStyleBackColor = True
        '
        'btnHexB
        '
        Me.btnHexB.Enabled = False
        Me.btnHexB.Location = New System.Drawing.Point(207, 551)
        Me.btnHexB.Name = "btnHexB"
        Me.btnHexB.Size = New System.Drawing.Size(76, 72)
        Me.btnHexB.TabIndex = 22
        Me.btnHexB.Text = "B"
        Me.btnHexB.UseVisualStyleBackColor = True
        '
        'btnHexC
        '
        Me.btnHexC.Enabled = False
        Me.btnHexC.Location = New System.Drawing.Point(298, 551)
        Me.btnHexC.Name = "btnHexC"
        Me.btnHexC.Size = New System.Drawing.Size(76, 72)
        Me.btnHexC.TabIndex = 23
        Me.btnHexC.Text = "C"
        Me.btnHexC.UseVisualStyleBackColor = True
        '
        'btnHexD
        '
        Me.btnHexD.Enabled = False
        Me.btnHexD.Location = New System.Drawing.Point(391, 551)
        Me.btnHexD.Name = "btnHexD"
        Me.btnHexD.Size = New System.Drawing.Size(76, 72)
        Me.btnHexD.TabIndex = 24
        Me.btnHexD.Text = "D"
        Me.btnHexD.UseVisualStyleBackColor = True
        '
        'btnHexE
        '
        Me.btnHexE.Enabled = False
        Me.btnHexE.Location = New System.Drawing.Point(483, 551)
        Me.btnHexE.Name = "btnHexE"
        Me.btnHexE.Size = New System.Drawing.Size(76, 72)
        Me.btnHexE.TabIndex = 25
        Me.btnHexE.Text = "E"
        Me.btnHexE.UseVisualStyleBackColor = True
        '
        'btnHexF
        '
        Me.btnHexF.Enabled = False
        Me.btnHexF.Location = New System.Drawing.Point(574, 551)
        Me.btnHexF.Name = "btnHexF"
        Me.btnHexF.Size = New System.Drawing.Size(76, 72)
        Me.btnHexF.TabIndex = 26
        Me.btnHexF.Text = "F"
        Me.btnHexF.UseVisualStyleBackColor = True
        '
        'btn0
        '
        Me.btn0.Location = New System.Drawing.Point(114, 643)
        Me.btn0.Name = "btn0"
        Me.btn0.Size = New System.Drawing.Size(76, 72)
        Me.btn0.TabIndex = 27
        Me.btn0.Text = "0"
        Me.btn0.UseVisualStyleBackColor = True
        '
        'btn1
        '
        Me.btn1.Location = New System.Drawing.Point(207, 643)
        Me.btn1.Name = "btn1"
        Me.btn1.Size = New System.Drawing.Size(76, 72)
        Me.btn1.TabIndex = 28
        Me.btn1.Text = "1"
        Me.btn1.UseVisualStyleBackColor = True
        '
        'btn2
        '
        Me.btn2.Enabled = False
        Me.btn2.Location = New System.Drawing.Point(298, 643)
        Me.btn2.Name = "btn2"
        Me.btn2.Size = New System.Drawing.Size(76, 72)
        Me.btn2.TabIndex = 29
        Me.btn2.Text = "2"
        Me.btn2.UseVisualStyleBackColor = True
        '
        'btn3
        '
        Me.btn3.Enabled = False
        Me.btn3.Location = New System.Drawing.Point(391, 643)
        Me.btn3.Name = "btn3"
        Me.btn3.Size = New System.Drawing.Size(76, 72)
        Me.btn3.TabIndex = 30
        Me.btn3.Text = "3"
        Me.btn3.UseVisualStyleBackColor = True
        '
        'btn4
        '
        Me.btn4.Enabled = False
        Me.btn4.Location = New System.Drawing.Point(114, 736)
        Me.btn4.Name = "btn4"
        Me.btn4.Size = New System.Drawing.Size(76, 72)
        Me.btn4.TabIndex = 31
        Me.btn4.Text = "4"
        Me.btn4.UseVisualStyleBackColor = True
        '
        'btn5
        '
        Me.btn5.Enabled = False
        Me.btn5.Location = New System.Drawing.Point(207, 736)
        Me.btn5.Name = "btn5"
        Me.btn5.Size = New System.Drawing.Size(76, 72)
        Me.btn5.TabIndex = 32
        Me.btn5.Text = "5"
        Me.btn5.UseVisualStyleBackColor = True
        '
        'btn6
        '
        Me.btn6.Enabled = False
        Me.btn6.Location = New System.Drawing.Point(298, 736)
        Me.btn6.Name = "btn6"
        Me.btn6.Size = New System.Drawing.Size(76, 72)
        Me.btn6.TabIndex = 33
        Me.btn6.Text = "6"
        Me.btn6.UseVisualStyleBackColor = True
        '
        'btn7
        '
        Me.btn7.Enabled = False
        Me.btn7.Location = New System.Drawing.Point(391, 736)
        Me.btn7.Name = "btn7"
        Me.btn7.Size = New System.Drawing.Size(76, 72)
        Me.btn7.TabIndex = 34
        Me.btn7.Text = "7"
        Me.btn7.UseVisualStyleBackColor = True
        '
        'btn8
        '
        Me.btn8.Enabled = False
        Me.btn8.Location = New System.Drawing.Point(114, 825)
        Me.btn8.Name = "btn8"
        Me.btn8.Size = New System.Drawing.Size(76, 72)
        Me.btn8.TabIndex = 35
        Me.btn8.Text = "8"
        Me.btn8.UseVisualStyleBackColor = True
        '
        'btn9
        '
        Me.btn9.Enabled = False
        Me.btn9.Location = New System.Drawing.Point(207, 825)
        Me.btn9.Name = "btn9"
        Me.btn9.Size = New System.Drawing.Size(76, 72)
        Me.btn9.TabIndex = 36
        Me.btn9.Text = "9"
        Me.btn9.UseVisualStyleBackColor = True
        '
        'btnConvert
        '
        Me.btnConvert.Location = New System.Drawing.Point(483, 643)
        Me.btnConvert.Name = "btnConvert"
        Me.btnConvert.Size = New System.Drawing.Size(167, 254)
        Me.btnConvert.TabIndex = 37
        Me.btnConvert.Text = "Convert"
        Me.btnConvert.UseVisualStyleBackColor = True
        '
        'btnClearVal1
        '
        Me.btnClearVal1.Location = New System.Drawing.Point(1068, 551)
        Me.btnClearVal1.Name = "btnClearVal1"
        Me.btnClearVal1.Size = New System.Drawing.Size(353, 72)
        Me.btnClearVal1.TabIndex = 38
        Me.btnClearVal1.Text = "Clear Value 1"
        Me.btnClearVal1.UseVisualStyleBackColor = True
        '
        'btnClearVal2
        '
        Me.btnClearVal2.Location = New System.Drawing.Point(1068, 643)
        Me.btnClearVal2.Name = "btnClearVal2"
        Me.btnClearVal2.Size = New System.Drawing.Size(353, 72)
        Me.btnClearVal2.TabIndex = 39
        Me.btnClearVal2.Text = "Clear Value 2"
        Me.btnClearVal2.UseVisualStyleBackColor = True
        '
        'btnClearRes
        '
        Me.btnClearRes.Location = New System.Drawing.Point(1068, 736)
        Me.btnClearRes.Name = "btnClearRes"
        Me.btnClearRes.Size = New System.Drawing.Size(353, 72)
        Me.btnClearRes.TabIndex = 40
        Me.btnClearRes.Text = "Clear Result"
        Me.btnClearRes.UseVisualStyleBackColor = True
        '
        'btnAnd
        '
        Me.btnAnd.Location = New System.Drawing.Point(1917, 551)
        Me.btnAnd.Name = "btnAnd"
        Me.btnAnd.Size = New System.Drawing.Size(260, 72)
        Me.btnAnd.TabIndex = 41
        Me.btnAnd.Text = "AND"
        Me.btnAnd.UseVisualStyleBackColor = True
        '
        'btnOr
        '
        Me.btnOr.Location = New System.Drawing.Point(1917, 643)
        Me.btnOr.Name = "btnOr"
        Me.btnOr.Size = New System.Drawing.Size(260, 72)
        Me.btnOr.TabIndex = 42
        Me.btnOr.Text = "OR"
        Me.btnOr.UseVisualStyleBackColor = True
        '
        'btnXor
        '
        Me.btnXor.Location = New System.Drawing.Point(1917, 736)
        Me.btnXor.Name = "btnXor"
        Me.btnXor.Size = New System.Drawing.Size(260, 72)
        Me.btnXor.TabIndex = 43
        Me.btnXor.Text = "XOR"
        Me.btnXor.UseVisualStyleBackColor = True
        '
        'btnNotVal1
        '
        Me.btnNotVal1.Location = New System.Drawing.Point(1917, 825)
        Me.btnNotVal1.Name = "btnNotVal1"
        Me.btnNotVal1.Size = New System.Drawing.Size(260, 72)
        Me.btnNotVal1.TabIndex = 44
        Me.btnNotVal1.Text = "Not Value 1"
        Me.btnNotVal1.UseVisualStyleBackColor = True
        '
        'btnClearAllVal
        '
        Me.btnClearAllVal.Location = New System.Drawing.Point(1068, 825)
        Me.btnClearAllVal.Name = "btnClearAllVal"
        Me.btnClearAllVal.Size = New System.Drawing.Size(353, 72)
        Me.btnClearAllVal.TabIndex = 45
        Me.btnClearAllVal.Text = "Clear ALL Values"
        Me.btnClearAllVal.UseVisualStyleBackColor = True
        '
        'calcChild
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(19.0!, 37.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.AutoScroll = True
        Me.ClientSize = New System.Drawing.Size(2469, 1180)
        Me.Controls.Add(Me.btnClearAllVal)
        Me.Controls.Add(Me.btnNotVal1)
        Me.Controls.Add(Me.btnXor)
        Me.Controls.Add(Me.btnOr)
        Me.Controls.Add(Me.btnAnd)
        Me.Controls.Add(Me.btnClearRes)
        Me.Controls.Add(Me.btnClearVal2)
        Me.Controls.Add(Me.btnClearVal1)
        Me.Controls.Add(Me.btnConvert)
        Me.Controls.Add(Me.btn9)
        Me.Controls.Add(Me.btn8)
        Me.Controls.Add(Me.btn7)
        Me.Controls.Add(Me.btn6)
        Me.Controls.Add(Me.btn5)
        Me.Controls.Add(Me.btn4)
        Me.Controls.Add(Me.btn3)
        Me.Controls.Add(Me.btn2)
        Me.Controls.Add(Me.btn1)
        Me.Controls.Add(Me.btn0)
        Me.Controls.Add(Me.btnHexF)
        Me.Controls.Add(Me.btnHexE)
        Me.Controls.Add(Me.btnHexD)
        Me.Controls.Add(Me.btnHexC)
        Me.Controls.Add(Me.btnHexB)
        Me.Controls.Add(Me.btnHexA)
        Me.Controls.Add(Me.txtResHex)
        Me.Controls.Add(Me.txtVal2Hex)
        Me.Controls.Add(Me.txtVal1Hex)
        Me.Controls.Add(Me.lblResHex)
        Me.Controls.Add(Me.lblVal2Hex)
        Me.Controls.Add(Me.lblVal1Hex)
        Me.Controls.Add(Me.txtResDec)
        Me.Controls.Add(Me.txtVal2Dec)
        Me.Controls.Add(Me.txtVal1Dec)
        Me.Controls.Add(Me.lblResDec)
        Me.Controls.Add(Me.lblVal2Dec)
        Me.Controls.Add(Me.lblVal1Dec)
        Me.Controls.Add(Me.txtResBin)
        Me.Controls.Add(Me.txtVal2Bin)
        Me.Controls.Add(Me.txtVal1Bin)
        Me.Controls.Add(Me.lblResBin)
        Me.Controls.Add(Me.lblVal2Bin)
        Me.Controls.Add(Me.lblVal1Bin)
        Me.Controls.Add(Me.lblRes)
        Me.Controls.Add(Me.lblVal2)
        Me.Controls.Add(Me.lblVal1)
        Me.Name = "calcChild"
        Me.Text = "Calculator"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents lblVal1 As Label
    Friend WithEvents lblVal2 As Label
    Friend WithEvents lblRes As Label
    Friend WithEvents lblVal1Bin As Label
    Friend WithEvents lblVal2Bin As Label
    Friend WithEvents lblResBin As Label
    Friend WithEvents lblVal1Dec As Label
    Friend WithEvents lblVal2Dec As Label
    Friend WithEvents lblResDec As Label
    Friend WithEvents lblVal1Hex As Label
    Friend WithEvents lblVal2Hex As Label
    Friend WithEvents lblResHex As Label
    Friend WithEvents btnHexA As Button
    Friend WithEvents btnHexB As Button
    Friend WithEvents btnHexC As Button
    Friend WithEvents btnHexD As Button
    Friend WithEvents btnHexE As Button
    Friend WithEvents btnHexF As Button
    Friend WithEvents btn0 As Button
    Friend WithEvents btn1 As Button
    Friend WithEvents btn2 As Button
    Friend WithEvents btn3 As Button
    Friend WithEvents btn4 As Button
    Friend WithEvents btn5 As Button
    Friend WithEvents btn6 As Button
    Friend WithEvents btn7 As Button
    Friend WithEvents btn8 As Button
    Friend WithEvents btn9 As Button
    Friend WithEvents btnConvert As Button
    Friend WithEvents btnClearVal1 As Button
    Friend WithEvents btnClearVal2 As Button
    Friend WithEvents btnClearRes As Button
    Friend WithEvents btnAnd As Button
    Friend WithEvents btnOr As Button
    Friend WithEvents btnXor As Button
    Friend WithEvents btnNotVal1 As Button
    Friend WithEvents btnClearAllVal As Button
    Public WithEvents txtVal1Dec As TextBox
    Public WithEvents txtVal1Bin As TextBox
    Public WithEvents txtVal2Bin As TextBox
    Public WithEvents txtResBin As TextBox
    Public WithEvents txtVal2Dec As TextBox
    Public WithEvents txtResDec As TextBox
    Public WithEvents txtVal1Hex As TextBox
    Public WithEvents txtVal2Hex As TextBox
    Public WithEvents txtResHex As TextBox
End Class
