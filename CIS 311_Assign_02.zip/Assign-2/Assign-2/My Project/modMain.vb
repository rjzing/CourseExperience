﻿Module modMain
    Sub Main()
        Form1.ShowDialog()
        'If Form1.cmdPlaceOrder = clicked Then

        'End If
    End Sub
End Module
